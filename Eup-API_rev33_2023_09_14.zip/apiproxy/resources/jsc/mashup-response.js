var userResponse = JSON.parse(context.getVariable('response.content'));
var userPermisionResponse = JSON.parse(context.getVariable('userPermissionResponse.content'));
userResponse.function = userPermisionResponse.function;
context.setVariable('response.content', JSON.stringify(userResponse));